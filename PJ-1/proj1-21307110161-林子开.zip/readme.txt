report.pdf是本次Project的报告

codes文件夹中含有本次Project的项目文件（二叉搜索树、红黑树和B树），测试用例，GUI设计文件，以及程序输出结果。具体介绍请参考report.pdf的第一小节。